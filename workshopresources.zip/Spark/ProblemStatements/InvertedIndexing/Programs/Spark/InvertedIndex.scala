package InvertedIndexing

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf



object InvertedIndex {

  def main (args:Array[String]){
    val conf = new SparkConf().setMaster("local").setAppName("InvertIndexing")
    //val conf = new SparkConf().setAppName("Inverted Indexing")
    //val sc = new SparkContext(new SparkConf().setAppName("Inverted Indexing"))
    val sc = new SparkContext(conf)
    val rdd = sc.textFile("hdfs://localhost:9000/data/departments")
    val groupRDD = rdd.map(_.split(" ")).flatMap(x => x.drop(1).map(y => (y, x(0)))).groupBy(_._1)
    val resultRDD = groupRDD.map(p => (p._1,p._2.map(_._2))).map(s =>(s._1 + "::" + s._2.mkString(",")))
    resultRDD.saveAsTextFile("hdfs://localhost:9000/outinvertindexresults")
  }
}

