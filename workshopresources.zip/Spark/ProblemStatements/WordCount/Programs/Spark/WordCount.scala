package bigdata.spark_examples

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf


object hellowworld {
  def main (args:Array[String]){
    val conf = new SparkConf().setMaster("local").setAppName("WordCount")
    val sc = new SparkContext(conf)
    val rdd = sc.textFile("hdfs://localhost:9000/hdfs-site.xml")
    val result = rdd.flatMap(_.split(" ")).map(word => (word,1)).reduceByKey(_+_).collect().foreach { println }
  }
}
    
    
    
   
    
    
  
  
  
