//class BankAccount (Id:Int,Balance:Double)
//class BankAccount (var Id:Int,var Balance:Double)
case class BankAccount (Id:Int,Balance:Double){
override def toString():String = {
return Id + "::" + Balance	
}
}


case class BankAccount (Id:Int,Balance:Double){
override def toString= Id + "::" + Balance
def minus (that:BankAccount) = Balance - that.Balance
def - (that:BankAccount) = minus (that)	
}


