
public class BankAccount {

	private final int Id;
	private final double Balance;
	
	BankAccount(int id, double amount)
	{
		Id = id;
		Balance = amount;
	}
	public int getId()
	{
		return Id;
	}
	public double getBalance()
	{
		return Balance;
	}
	
	public double minus (BankAccount that)
	{
		return this.Balance - that.Balance;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        BankAccount other = (BankAccount) obj;
        if (Id != other.Id)
            return false;
        return true;
	}
	
	@Override
	public int hashCode() {
		final int prime = 7;
        int result = 1;
        result = prime * result + Id;
        return result;
	}
	

}
