1.Please copy files in Dataset folder to bin folder of Spark installation directory.
2.Please change the data file paths as per your configuration in source code files for practicals.
3.type, ": paste" when you are copying multiple lines from file when you are copying.
4.Press Ctrl + D when paste operation is done.